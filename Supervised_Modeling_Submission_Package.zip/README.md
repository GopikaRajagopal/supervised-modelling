# Supervised Classification / Regression Modeling & Tuning

## Included files
- `Supervised_Classification_Regression_Modeling.ipynb` — end-to-end notebook for preprocessing, four-model comparison, GridSearchCV tuning, evaluation, plots, and model serialization.
- `requirements.txt` — Python dependencies.
- `model_comparison.csv` and `cross_validation_results.csv` — generated when the notebook is run.
- `champion_model.joblib` — generated serialized champion model.

## How to run
1. Install Python 3.9+ and Jupyter.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Place your dataset CSV in this folder.
4. Open the notebook:
   ```bash
   jupyter notebook
   ```
5. In the Configuration section, update:
   - `DATA_PATH` to your CSV filename.
   - `TARGET_COLUMN` to the exact column you want to predict.
   - `TASK` to `classification` or `regression`.
6. Run all cells from top to bottom.
7. Review the generated comparison tables and plots. The notebook selects the champion model and saves it as `champion_model.joblib`.

## Evaluation
For classification, the notebook reports weighted precision, recall, F1-score, accuracy, ROC-AUC when available, confusion matrix, classification report, and ROC curves.

For regression, it reports RMSE, MAE, and R².

## Notes
- Preprocessing is placed inside each model pipeline to avoid fitting imputers, scalers, or encoders on the test set.
- Classification uses stratified 5-fold cross-validation. Regression uses shuffled 5-fold K-fold cross-validation because stratification is intended for classification targets.
- The held-out test split is used for final model comparison. The model is then refit on the training split by GridSearchCV.
- No dataset was included with the assignment screenshot. Therefore, actual scores and a trained `.joblib` artifact are generated only after you supply and run the notebook on your dataset.
